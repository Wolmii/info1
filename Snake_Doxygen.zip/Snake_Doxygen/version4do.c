/**
* \brief Programme snake dans un terminal.
* \author REGNIER Mathilde
* \version 4.0
* \date novembre 2024
*
* Ce programme fais fonctionner un snake dans le terminal, avec un plateau, des pommes, et déplaçable avec zqsd.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <stdbool.h>
#include <time.h>

/*****************************************************
 *               Déclarations des constantes          *
 *****************************************************/

/**
* \def TAILLE
* \brief Constante de taille du serpent.
*/
#define TAILLE 10

/**
* \def TAILLE_MAX
* \brief Taille maximale du serpent.
*/
#define TAILLE_MAX 20

/**
* \def FIN
* \brief Constante qui définit la touche d'arret du programme.
*/
#define FIN 'a'

/**
* \def TEMPO
* \brief Constante pour le temps d'arret du programme, déterminant la vitesse du serpent.
*/
#define TEMPO 100000

/**
* \def QUEUE
* \brief Constante pour définir le caractère du corps du serpent.
*/
#define QUEUE 'X' 

/**
* \def TETE
* \brief Constante pour le caractère de la tête du serpent.
*/
#define TETE 'O' 

/**
* \def X
* \brief Constante de coodronnées de départ en x du serpent.
*/
#define X 40

/**
* \def Y
* \brief Constante de coordonnées de départ en y du serpent.
*/
#define Y 20 

/**
* \def DROITE
* \brief Constante pour déterminer la touche pour aller a droite.
*/
#define DROITE 'd' 

/**
* \def GAUCHE
* \brief Constante pour déterminer la touche pour aller a gauche.
*/
#define GAUCHE 'q'

/**
* \def HAUT
* \brief Constante pour déterminer la touche pour aller en bas.
*/
#define HAUT 'z' 

/**
* \def BAS
* \brief Constante pour déterminer la touche pour aller en haut.
*/
#define BAS 's' 

/**
* \def PLATHAUT
* \brief Constante de taille de hauteur du plateau.
*/
#define PLATHAUT 40 

/**
* \def PLATLARG 
* \brief Constante de taille de largeur du plateau.
*/
#define PLATLARG 80 

/**
* \def PLATEAU
* \brief Définition du motif de la bordure du plateau.
*/
#define PLATEAU '#' 

/**
* \def FOND
* \brief Definition du motif d'arrière plan du plateau.
*/
#define FOND ' ' 

/**
* \def PAVE
* \brief Definition du motif des pavés.
*/
#define PAVE '#' 

/**
* \def PAVEHAUT
* \brief Definition de la hauteur des pavés sur le plateau.
*/
#define PAVEHAUT 5 

/**
* \def PAVELARGE
* \brief Definition de la largeur des pavés sur le plateau.
*/
#define PAVELARGE 5 

/**
* \def NBPAVE
* \brief Definition du nombre de pavés présents sur le plateau.
*/
#define NBPAVE 4 

/**
* \def POMME
* \brief Definition du caractère qui sert de pomme.
*/
#define POMME '6' 

/**
* \def AUGM_VIT
* \brief Définition  de l'augmentation de la vitesse.
*/
#define AUGM_VIT 5000

/**
* \def GRANDIR
* \brief Définition du nombre d'augmentation de taille du serpent.
*/
#define GRANDIR 1

/*****************************************************
 *         Déclarations des variables globales        *
 *****************************************************/

/**
* \var char tab[PLATLARG][PLATHAUT]
* \brief Définition en variable globale du tableau pour le plateau.
*/
char tab[PLATLARG][PLATHAUT];

/**
* \var int tailleT=TAILLE
* \brief Définition d'une variable globale pour la taille du serpent a un instant t.
*/
int tailleT=TAILLE;

/*****************************************************
 *            Déclarations des procédures             *
 *****************************************************/

/**
*
* \fn int kbhit()
*
* \brief Fonction pour regarder si une touche est rentrée au clavier.
*
* \return 1 si un caractère est tappé, 0 si aucun.
*
* Consiste à vérifier si une touche est entrée au clavier, a retourner 1 si une touche est entrée, et 0 si aucune touche n'est entrée.
*
*/
int kbhit();

/**
*
* \fn void gotoXY(int x, int y)
*
* \brief Proédure pour positionner le curseur avant d'afficher le tête a cet endroit.
*
* \param ch : les coordonnées où se rendre.
*
* Consiste à faire aller le curseur a des coordonnées x et y au début du programme.
*
*/
void gotoXY(int x, int y);

/**
*
* \fn void afficher(int x, int y, char c)
*
* \brief Procédure pour afficher la tête du serpent
*
* \param x : Coordonnées de x où se rendre.
* \param y : Coordonnées de y où se rendre.
* \param c : Charactère a afficher aux coordonnées.
*
* Consiste à se rendre a des coordonnées données, et a y afficher un caractère.
*
*/
void afficher(int x, int y, char c);

/**
*
* \fn void effacer(int x, int y)
*
* \brief Procédure qui efface un caractère.
*
* \param x : Coordonnées de x où se rendre.
* \param y : Coordonnées de y où se rendre.
*
* Consiste à se rendre aux coordonnées données, et a effacer (place un espace) le derrière du serpent quand il avance.
*
*/
void effacer(int x, int y);

/**
*
* \fn void progresser(int lesX[tailleT], int lesY[tailleT], char direction, bool* collision, bool*manger)
*
* \brief Calculer l'avancée du serpent.
*
* \param lesX[tailleT] : Tableau de taille du serpent en x.
* \param lesY[tailleT] : Tableau de taille du serpent en y.
* \param direction : La touche tapée au clavier, quand elle est égale a une direction.
* \param collision : Booléen pour savoir si le serpent entre en collision avec quelque chose.
* \param manger : Booléen pour savoir si le serpent mange une pomme.
*
* Consiste à calculer l'avancée du serpent et son changement de sens en cas de touche utilisée. Il sert aussi a envoyer un signal quand un mur, un pavé, ou si le serpent se mange lui même. Ainsi que si il mange une pomme.
*
*/
void progresser(int lesX[tailleT], int lesY[tailleT], char direction, bool* collision, bool*manger);

/**
*
* \fn void dessinerSerpent(int lesX[tailleT], int lesY[tailleT])
*
* \brief Procédure qui dessine le serpent depuis les coordonnées données.
*
* \param lesX[tailleT] : Tableau de taille du serpent en x.
* \param lesY[tailleT] : Tableau de taille du serpent en y.
*
* Consiste à aller aux coordonnées de la tête, l'afficher, et afficher le reste du corps en suivant ce premier point.
*
*/
void dessinerSerpent(int lesX[tailleT], int lesY[tailleT]);

/**
*
* \fn void disableEcho()
*
* \brief Permet de ne plus afficher les touches rentrées au clavier.
*
* Consiste à empêcher que les touches que l'on tape au clavier n'aparaissent dans le terminal.
*
*/
void disableEcho();

/**
*
* \fn void enableEcho()
*
* \brief Affiche a nouveau les touches rentrées au clavier.
*
* Après disable echo(), sert a réactiver le fais que l'ont voie les touhes tapées au clavier dans le terminal.
*
*/
void enableEcho();

/**
*
* \fn void initPlateau(char tab[PLATLARG][PLATHAUT])
*
* \brief Procédure pour initialiser le plateau et les blocs dedans.
*
* \param tab[PLATLARG][PLATHAUT] : Un tableau de caractères la hauteur et de la largeur voulue.
*
* Consiste à créer et remplir un tableau avec les dimentions voulues, les bordures voulues, et place dedans un nombre de pavé voulu de manière aléatoire, en respectant certaines contraintes (pas sur le serpent au début, pas colé a une bordure), et place une pomme dedans.
*
*/
void initPlateau(char tab[PLATLARG][PLATHAUT]);

/**
*
* \fn void dessinerPlateau(char tab[PLATLARG][PLATHAUT])
*
* \brief Procédure qui consiste a afficher à l'écran le tableau en paramètre.
*
* \param tab[PLATLARG][PLATHAUT] : la chaine à tester.
*
* Consiste à ballayer le tableau, et a afficher a l'écran son contenu, donc le plateau, les pavés, et la pomme.
*
*/
void dessinerPlateau(char tab[PLATLARG][PLATHAUT]);

/**
*
* \fn void ajouter_pomme(char tab[PLATLARG][PLATHAUT], int lesX[tailleT], int lesY[tailleT])
*
* \brief Procédure qui place aléatoirement une pomme a une emplaceament libre du plateau.
*
* \param tab[PLATLARG][PLATHAUT] : Le tableau du plateau.
* \param lesX[tailleT] : Le tableau du serpent en X.
* \param int lesY[tailleT] : Le tableau du serpent en Y.
*
* Consiste à placer une pomme, après avoir vérifié que k'emplacement pour le mettre est libre (dans le tableau, pas de sur un pavé, aps sur le serpent).
*
*/
void ajouter_pomme(char tab[PLATLARG][PLATHAUT], int lesX[tailleT], int lesY[tailleT]); //place aléatoirement une pomme a une emplaceament libre du plateau

/*****************************************************
 *                  Programme principal              *
 *****************************************************/
/**
 * \fn int main()
 * @brief Fonction du programme principal.
 * \return EXIT_SUCCESS
 * Programme qui fais apparaitre et avancer un sepet, dans un plateau avec des pavés et des pommes, s'arrétant a un maximum de 10 pommes mangées.
 */
int main(){
/**
*
* \var int tabx[TAILLE_MAX], taby[TAILLE_MAX]
*
* \brief Définition du tableau du serpent.
*
*/
   int tabx[TAILLE_MAX], taby[TAILLE_MAX];
/**
*
* \var int duree=TEMPO
*
* \brief Temps d'arrêt du programme.
*
*/
   int duree=TEMPO;
/**
*
* \var char clav=DROITE, clavVerif
*
* \brief Lire le caractère au clavier, vérifier le caractère au clavier.
*
*/
   char clav=DROITE, clavVerif;
/**
*
* \var char clav=DROITE, clavVerif
*
* \brief Sert pour savoir si le serpent rentre dans quelque chose (true) ou non (false).
*
*/
   bool collision=false;
/**
*
* \var char clav=DROITE, clavVerif
*
* \brief Sert pour savoir si une pomme est mangée (true) ou non (false).
*
*/
   bool manger=false;

   for(int i=0; i<tailleT; i++){/** créer les coordonnées du serpent a partir de la tête*/
      tabx[i]=X-i;
      taby[i]=Y;
   }
   disableEcho();
   initPlateau(tab);
   system ("clear");
   dessinerPlateau(tab);
   dessinerSerpent(tabx, taby); /** dessiner le serpent depuis les coordonnées données*/
   ajouter_pomme(tab, tabx, taby);
   printf("\e[?25l");

   while(clav!=FIN && collision==false && tailleT<TAILLE_MAX){/** tant que le caractère au clavier n'est pas FIN (a ici)*/
      usleep(duree);
      progresser(tabx, taby, clav, &collision, &manger); /** faire avancer le serpent*/
      if(manger==true){ /** si une pomme est détectée comme mangée*/
         manger=false;
         duree-=AUGM_VIT; /** la vitesse du serpent augmente*/
         tailleT=tailleT+GRANDIR; /** la taille du serpent augmente*/
         if(tailleT!=TAILLE_MAX){
            ajouter_pomme(tab, tabx, taby); /** une nouvelle pomme apparait*/
         }
      }
      if(kbhit()==1){ /** si un caractère est tapé au clavier*/
         clavVerif=getchar();/** récupérer la touvhe au clavier pour la vérifier*/
         if(clavVerif==DROITE || clavVerif==GAUCHE || clavVerif==HAUT || clavVerif==BAS || clavVerif==FIN){ /** regarde si la touche est utilisée quelque part*/
            if((clav==DROITE && clavVerif==GAUCHE) || (clav==GAUCHE && clavVerif==DROITE) || (clav==HAUT && clavVerif==BAS) || (clav==BAS && clavVerif==HAUT)){ /**ne aps aller a droite si le serpent va a gauche, en haut si il va en bas,...*/
               clavVerif=clav;
            }
            clav=clavVerif; /** si elle sert, elle est sauvegardée pour être utilisée*/
         }
      }
   }
   if(tailleT==TAILLE_MAX){
      printf("Vous avez gagné !! :)");
   }
   else{
      printf("Vous avez perdu :(");
   }
   enableEcho();
   return EXIT_SUCCESS;
}

void gotoXY(int x, int y) { /** va aux coordonnées x et y données*/
   printf("\033[%d;%df", y, x);
}

void afficher(int x, int y, char c){ /** affiche un caractère à la position x et y*/
   gotoXY(x,y);
   printf("%c", c);
}

void effacer(int x, int y){ /** efface le caractère à la position x et y*/
   afficher(x, y, ' ');
}

void dessinerSerpent(int lesX[tailleT], int lesY[tailleT]){ /** dessine le serpent*/
   for (int i=1; i<tailleT; i++){/** dessine le corps*/
      if(lesX[i]>0 && lesY[i]>0){
         afficher(lesX[i], lesY[i], QUEUE);
      }
   }
   if(lesX[0]>0 && lesY[0]>0){
      afficher(lesX[0], lesY[0], TETE);/** affiche la tête aux coordonnées*/
   }
}

void progresser(int lesX[tailleT], int lesY[tailleT], char direction, bool* collision, bool* manger){ /** faire avancer le serpent*/
   effacer(lesX[tailleT-1], lesY[tailleT-1]);/** efface le dernier caractère du corps*/
   for(int i=tailleT; i>0; i--){
      lesX[i]=lesX[i-1];
      lesY[i]=lesY[i-1];
   }
   switch(direction) /** détermine la direction du serpent*/
   {
      case DROITE:/** claculer les nouvelles coordonnées du corps*/
         lesX[0]+=1;
         break;
      case GAUCHE :/** claculer les nouvelles coordonnées du corps*/
         lesX[0]-=1;
         break;
      case HAUT :/** claculer les nouvelles coordonnées du corps*/
         lesY[0]-=1;
         break;
      case BAS :/** claculer les nouvelles coordonnées du corps*/
         lesY[0]+=1;
         break;
      default :
         break;
   }
   if(lesX[0]==1){/** fais en sorte que si le serpent va dans le trou a gauche, il ressort a droite*/
      lesX[0]=PLATLARG;
   }
   else if(lesX[0]==PLATLARG){ /** fais en sorte que si le serpent va dans le trou a droite, il ressort a gauche*/
      lesX[0]=1;
   }
   else if(lesY[0]==1){/** fais en sorte que si le serpent va dans le trou en haut, il ressort en bas*/
      lesY[0]=PLATHAUT;
   }
   else if(lesY[0]==PLATHAUT){/** fais en sorte que si le serpent va dans le trou en bas, il ressort en haut*/
      lesY[0]=1;
   }

   for(int i=1; i<tailleT; i++){/** regarde si le serpent rentre en collision avec un élément du plateau*/
      if(((tab[lesX[0]-1][lesY[0]-1]==PLATEAU)) || ((tab[lesX[0]-1][lesY[0]-1]==PAVE)) || ((lesX[0]==lesX[i]) && (lesY[0]==lesY[i]))){
         *collision=true;
      }
   }

   if(tab[lesX[0]][lesY[0]]==POMME){/** si dans la case de la tête a une pomme dedans, le booléen deviens vrai*/
      *manger=true;
      tab[lesX[0]][lesY[0]]=FOND;
   }
   
   if(!*collision){
      dessinerSerpent(lesX, lesY);/** dessine le serpent aux nouvelles coordonnées*/
   }
}


void disableEcho() {
   struct termios tty;

   /** Obtenir les attributs du terminal*/
   if (tcgetattr(STDIN_FILENO, &tty) == -1) {
      perror("tcgetattr");
      exit(EXIT_FAILURE);
   }

   /** Desactiver le flag ECHO*/
   tty.c_lflag &= ~ECHO;

   /** Appliquer les nouvelles configurations*/
   if (tcsetattr(STDIN_FILENO, TCSANOW, &tty) == -1) {
      perror("tcsetattr");
      exit(EXIT_FAILURE);
   }
}

void enableEcho() {
   struct termios tty;

   /** Obtenir les attributs du terminal*/
   if (tcgetattr(STDIN_FILENO, &tty) == -1) {
      perror("tcgetattr");
      exit(EXIT_FAILURE);
   }

   /** Reactiver le flag ECHO*/
   tty.c_lflag |= ECHO;

   /** Appliquer les nouvelles configurations*/
   if (tcsetattr(STDIN_FILENO, TCSANOW, &tty) == -1) {
      perror("tcsetattr");
      exit(EXIT_FAILURE);
   }
}

int kbhit(){
   /** 
   * la fonction retourne :
   * 1 si un caractere est present
   * 0 si pas de caractere present
   */
   
   int unCaractere=0;
   struct termios oldt, newt;
   int ch;
   int oldf;

   /** mettre le terminal en mode non bloquant*/
   tcgetattr(STDIN_FILENO, &oldt);
   newt = oldt;
   newt.c_lflag &= ~(ICANON | ECHO);
   tcsetattr(STDIN_FILENO, TCSANOW, &newt);
   oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
   fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
   
   ch = getchar();

   /** restaurer le mode du terminal*/
   tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
   fcntl(STDIN_FILENO, F_SETFL, oldf);
   
   if(ch != EOF){
      ungetc(ch, stdin);
      unCaractere=1;
   }
   return unCaractere;
} /** regarder si quelque chose est tappé au clavier*/

void initPlateau(char tab[PLATLARG][PLATHAUT]){/** initialise le plateau*/
   int i, z, x, y;
   srand(time(NULL));
   for(z=1;z<=PLATHAUT+1;z++){ /** initialise les bordure du plateau*/
      for(i=1;i<=PLATLARG+1;i++){
         tab[i-1][z-1]=PLATEAU;
         }
      }
   for(z=2;z<PLATHAUT;z++){/** initialise le fond du plateau*/
      for(i=2;i<PLATLARG;i++){
         tab[i-1][z-1]=FOND;
      }
   }
   tab[PLATLARG/2][0]=FOND;
   tab[PLATLARG/2][PLATHAUT-1]=FOND;
   tab[0][PLATHAUT/2]=FOND;
   tab[PLATLARG-1][PLATHAUT/2]=FOND;

   for(int o=0; o<NBPAVE;o++){/** initialise les pavés dans le plateau*/
      x=rand()%PLATLARG;
      y=rand()%PLATHAUT;
      while(y<2||y>PLATHAUT-PAVEHAUT-2||x<2||x>PLATLARG-PAVELARGE-2||(((((X-TAILLE)-PAVELARGE)<x) && (x<(X+PAVELARGE+2)))&&((((Y-PAVEHAUT)-1)<y) && (y<(Y+1))))){
         /** sers a ce que les pavés ne soient aps collés au bord, ou sur le serpent au début*/
         x=rand()%PLATLARG;
         y=rand()%PLATHAUT;
      }
      for(int u=0; u<PAVEHAUT; u++){
         for(int j=0; j<PAVELARGE; j++){
            tab[x+u][y+j]=PAVE;
         }
      }
   }
}


void dessinerPlateau(char tab[PLATLARG][PLATHAUT]){/** dessine le plateau*/
   int i,z;
   for(i=0; i<PLATHAUT; i++){
      for(z=0; z<PLATLARG; z++){
         afficher(z+1,i+1,tab[z][i]);
      }
   }
}

void ajouter_pomme(char tab[PLATLARG][PLATHAUT],int lesX[tailleT],int lesY[tailleT]){ /** place aléatoirement une pomme a une emplaceament libre du plateau*/
   int x,y;
   bool pomme=false;
   srand(time(NULL));
   x=rand()%PLATLARG-1;
   y=rand()%PLATHAUT-1;
   for(int u=0; u<tailleT; u++){
      if(tab[lesX[u]][lesY[u]]==POMME){
         pomme=true;
      }
   }
   while(tab[x][y]!=FOND || pomme==true){ /** ||(pommeSerpent(tabx, taby, x, y)*/
      x=rand()%PLATLARG-1;
      y=rand()%PLATHAUT-1;
      pomme=false;
   }
   for(int u=0; u<tailleT; u++){
      if(tab[lesX[u]][lesY[u]]!=POMME){
         pomme=false;
      }
   }
   tab[x][y]=POMME;
   afficher(x,y,POMME);
}

/** 
*  Pour ajouetr_pomme, j'ai essayé de passer tabx et taby en variable globale, pour ne pas a avoir a le rajouter en entrée, mais ça ne marchais pas.
*  Pour des raisons qui me sont inconnues (et ayant demandé a d'autre amis, leur est inconnue aussi), lorsque je le mettais en variable globale, 
*  plus rien ne s'affichait sur mon écran (alors que je faisais exactement comme les autres).
*  J'ai donc deux parapètre d'entrée en trop dans ajouter_pomme, mais un programme fonctionnel.
*  Le problème vient peut être aussi de mon compilateur de c en ligne, car je n'ai pas de vm sur mon pc (j'en ai installé une, qui affiche un écran noir dés
*  que je me connecte).
*/